﻿using System;

namespace _002_练习
{
    class Program
    {
        //入口方法Main方法
        static void Main(string[] args)
        {
            //Console.WriteLine("*");
            //Console.WriteLine("**");
            //Console.WriteLine("***");
            //Console.WriteLine("****");
            //Console.WriteLine("*");
            //Console.WriteLine("*");
            //Console.WriteLine("*");

            //Console.WriteLine("   *");
            //Console.WriteLine("  ***");
            //Console.WriteLine(" *****");
            //Console.WriteLine("*******");
            //Console.WriteLine("   *");
            //Console.WriteLine("   *");
            //Console.WriteLine("   *");

            //Console.WriteLine("\\\"");

            Console.WriteLine("SiKi说:\"what is\\n\"");
            //Console.WriteLine("\\\"");
            
        }
    }
}
