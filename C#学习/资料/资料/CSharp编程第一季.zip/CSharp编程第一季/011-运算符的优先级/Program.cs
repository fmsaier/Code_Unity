﻿using System;

namespace _011_运算符的优先级
{
    class Program
    {
        static void Main(string[] args)
        {
            int res = (3 + 2) * 4;
            
            Console.WriteLine(res);
        }
    }
}
