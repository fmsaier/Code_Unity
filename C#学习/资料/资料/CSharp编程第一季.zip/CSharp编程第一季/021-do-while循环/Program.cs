﻿using System;

namespace _021_do_while循环
{
    class Program
    {
        static void Main(string[] args)
        {
            //while () { 
            //}

            // 1- 10

            int i = 1;

            //do {
            //    Console.WriteLine(i);
            //    i++;
            //} while (i<11);

            //while (i < 11)
            //{
            //    Console.WriteLine(i);
            //    i++;
            //}
            
            //for
            //while (i < 0)
            //{
            //    Console.WriteLine("i < 0");
            //}

            do
            {
                Console.WriteLine("i < 0");
            } while (i < 0);


        }
    }
}
