﻿using System;

namespace _016_switch分支语句
{
    class Program
    {
        static void Main(string[] args)
        {
            //int number = Convert.ToInt32(Console.ReadLine());
            //if (number == 1)
            //{
            //    Console.WriteLine("矿泉水");
            //}else if (number == 2)
            //{
            //    Console.WriteLine("红茶");
            //}else if (number == 3)
            //{
            //    Console.WriteLine("绿茶");
            //}
            //else if (number == 4)
            //{
            //    Console.WriteLine("雪碧");
            //}
            //else if (number == 5)
            //{
            //    Console.WriteLine("可口可乐");
            //}
            //else
            //{
            //    Console.WriteLine("脉动");
            //}

            //switch (number)
            //{
            //    case 1:
            //        Console.WriteLine("矿泉水");
            //        Console.WriteLine("矿泉水");
            //        break;
            //    case 2:
            //        Console.WriteLine("红茶");
            //        break;
            //    case 3:
            //        Console.WriteLine("绿茶");
            //        break;
            //    case 4:
            //        Console.WriteLine("雪碧");
            //        break;
            //    case 5:
            //        Console.WriteLine("可口可乐");
            //        break;
            //    case 6:
            //        Console.WriteLine("脉动");
            //        break;
            //    default:
            //        Console.WriteLine("没有你要购买的商品");
            //        break;
            //}

            //int weekNum = Convert.ToInt32(Console.ReadLine());

            //switch (weekNum)
            //{
            //    case 1:
            //    case 2:
            //        Console.WriteLine("Arduino");
            //        break;
            //    case 3:
            //    case 4:
            //    case 5:
            //        Console.WriteLine("C++");
            //        break;
            //    case 6:
            //    case 7:
            //        Console.WriteLine("Scratch");
            //        break;
            //}
            //
            // if switch


            //int x = 1, a = 0, b = 0; 
            //switch (x) { 
            //    case 0: 
            //    case 1: a++; 
            //    case 2: a++,b++; 
            //}
            //Console.WriteLine("a="+a+" b="+b);

        }
    }
}
