﻿using System;

namespace _044_常量
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //变量 常量
            int i = 12;
            i = 20;

            const int j = 100;

            const double PI = 3.141592;//

            double temp = PI * 90;

            Console.WriteLine(PI);
        }
    }
}
