﻿using System;

namespace _006_变量研究
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a = 5, b = 10;

            ////int class namespace string void

            ////a = b;
            ////b = a;

            ////int temp = a;
            ////a = b;
            ////b = temp;

            //a = a + b;
            //b = a - b;
            //a = a - b;

            //Console.WriteLine(a);
            //Console.WriteLine(b);

            //int age;
            //int myAge;int xiaomingAge;
            //double ememyHp;
            //double PI;
            //int HP;
            //int MP;

            int a = 23, b = 45;
            // 23+45=68
            //Console.WriteLine(a + "+" + b + "=" + (a + b));
            Console.WriteLine("{0}+{1}={2}", a, b, a + b);//0 1 2 

            Console.WriteLine("两个数字相加{0}+{0}={2}", 34, 123, 4);

            Console.WriteLine("两个数字相加{0}+{0}={3}", 34, 123, 4);
        }
    }
}
