﻿using System; //注释：引入命名空间

namespace _001_开始
{
    //这个是Program类
    class Program
    {
        //这个是Main方法
        /* sdfs  
         * sdf
         * sdf
         * sdf
         */
        static void Main(string[] args)
        {
            //ctrl + k   Ctrl +c   
            //Console.WriteLine("Hello World!1");//这个是输出语句

            /*sdf
        sdf     sdf
             sdf
            df */

            //Console.WriteLine("Hello World!2"); 

            //Console.WriteLine("Hellodfdsfds fsd你好 World3");

            //Console.Write("Hello World!");
            //Console.Write("www.sikiedu.com");
            Console.WriteLine("Hello ");
            Console.WriteLine("World!");
            //转义
            Console.WriteLine("He\tllo \nWorld!\\");
        }
    }
}
