﻿using System;

namespace _003_变量
{
    class Program
    {
        static void Main(string[] args)
        {

            //创建变量
            //创建了一个数据的容器，容器的名字叫做age，容器的类型是int
            //声明了一个变量，变量的名字是age
            //int age;//int变量类型 age变量名
            ////往容器里面放东西 赋值
            //age = 10;

            //double age2;

            //char age3;

            //double height;

            ////char sex;

            //int count;

            //double ave;
            
            //int total;

            //double temperature;

            //double wendu;

            ////赋值
            //total = 4;

            ////int a;
            ////a = 1;
            ////int b = 1;//
            ////a = 2;

            //int a = 1; 
            //a = 3 + 7 - 2; 

            //int b = 3; 
            //b = b + 1;

            //Console.WriteLine(a);
            //Console.WriteLine(b);

            //int c;
            //c = 10;//初始化
            //c = 11;
            //Console.WriteLine(c);

            ////female male
            //char sex = 'f';
            //sex = 'm';

            //int a = 1;
            int a = 3, b = 8;
            Console.WriteLine(a + b); // 11
            Console.WriteLine("a + b"); //a + b
            Console.WriteLine(a + "+" + b); // 3+8
            Console.WriteLine("a+b" + a + b); //a+b38
            Console.WriteLine("a+b" + (a + b));// a+b11
        }
    }
}
