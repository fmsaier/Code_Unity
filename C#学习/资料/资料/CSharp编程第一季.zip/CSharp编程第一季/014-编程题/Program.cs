﻿using System;

namespace _014_编程题
{
    class Program
    {
        static void Main(string[] args)
        {
            //int year = Convert.ToInt32(Console.ReadLine());


            //if( (year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
            //{
            //    Console.WriteLine("是闰年");
            //}
            //else
            //{
            //    Console.WriteLine("不是闰年");
            //}

            //int number = Convert.ToInt32(Console.ReadLine());
            //if (number < 0)
            //{
            //    Console.WriteLine(0 - number);
            //}
            //else
            //{
            //    Console.WriteLine(number);
            //}

            //int a = Convert.ToInt32(Console.ReadLine());
            //int b = Convert.ToInt32(Console.ReadLine());
            //int c = Convert.ToInt32(Console.ReadLine());
            //int max = a;
            //if (b > max)
            //{
            //    max = b;
            //}

            //if (c > max)
            //{
            //    max = c;
            //}
            //Console.WriteLine(c*c);

            //char a = Convert.ToChar(Console.ReadLine());
            //char b = Convert.ToChar(Console.ReadLine());
            //if( a>b)
            //{
            //    Console.WriteLine("{0}>{1}", a, b);
            //}
            //else
            //{
            //    Console.WriteLine("{0}<{1}", a, b);
            //}

            //char sex = Convert.ToChar(Console.ReadLine());
            //int number = Convert.ToInt32(Console.ReadLine());
            //if (sex == 'F')
            //{
            //    //Console.WriteLine("800M长跑");
            //    string project = "800M长跑";
            //    if ( number%2==1)
            //        //Console.WriteLine("跳绳");
            //        project += " 跳绳";
            //    else
            //        //Console.WriteLine("仰卧起坐");
            //        project += " 仰卧起坐";
            //    Console.WriteLine(project);
            //}
            //else
            //{
            //    Console.WriteLine("1000M长跑");
            //    if (number % 2 == 1)
            //    {
            //        Console.WriteLine("跳远");
            //    }
            //    else
            //    {
            //        Console.WriteLine("俯卧撑");
            //    }
            //}

            int x = 5, a = 0, b = 0; 
            if (x == a + b) Console.WriteLine("****"); 
            else Console.WriteLine("####");

        }
    }
}
